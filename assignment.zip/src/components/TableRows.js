import React, { useState } from "react";

export default function TableRows() {
  return (
    <>
      <tr>
        <td>- </td>
        <td>- </td>
        <td>-</td>
        <td>-</td>
        <td>-</td>
      </tr>
      <tr>
        <td>- </td>
        <td>- </td>
        <td>-</td>
        <td>-</td>
        <td>-</td>
      </tr>
      <tr>
        <td>- </td>
        <td>- </td>
        <td>-</td>
        <td>-</td>
        <td>-</td>
      </tr>
    </>
  );
}
